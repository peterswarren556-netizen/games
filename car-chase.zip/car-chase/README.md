# Night Pursuit

A top-down car chase game in plain HTML, CSS and JavaScript. No install needed.

## Run it
Open `index.html` in any browser, or serve the folder: `python -m http.server 8000` then visit http://localhost:8000

## Files
- `index.html` - page structure, HUD, menu, touch buttons
- `style.css` - layout and look
- `game.js` - driving physics, police AI, coins, scoring, rendering

## Controls
Arrow keys or WASD to drive. Space to start. Touch buttons appear on phones.

## Ideas to extend
- Add obstacles and building collisions
- Add sound with the Web Audio API
- Add a nitro boost or power-ups
- Wrap it as an Android app with Capacitor
