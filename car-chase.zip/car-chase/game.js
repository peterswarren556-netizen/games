// Night Pursuit - a top-down car chase game (plain HTML5 canvas, no libraries).
const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const ui = {
  score: document.getElementById("score"), coins: document.getElementById("coins"),
  health: document.getElementById("health"), best: document.getElementById("best"),
  menu: document.getElementById("menu"), start: document.getElementById("startBtn"),
};

function resize() { canvas.width = innerWidth; canvas.height = innerHeight; }
addEventListener("resize", resize); resize();

// ---------- Input ----------
const keys = { up: false, down: false, left: false, right: false };
const keyMap = { ArrowUp: "up", w: "up", ArrowDown: "down", s: "down", ArrowLeft: "left", a: "left", ArrowRight: "right", d: "right" };
addEventListener("keydown", e => {
  if (keyMap[e.key]) { keys[keyMap[e.key]] = true; e.preventDefault(); }
  if (e.code === "Space" && state.mode !== "play") startGame();
});
addEventListener("keyup", e => { if (keyMap[e.key]) keys[keyMap[e.key]] = false; });
document.querySelectorAll("#touch button").forEach(btn => {
  const k = btn.dataset.key;
  const set = v => e => { e.preventDefault(); keys[k] = v; btn.classList.toggle("on", v); };
  ["pointerdown"].forEach(ev => btn.addEventListener(ev, set(true)));
  ["pointerup", "pointerleave", "pointercancel"].forEach(ev => btn.addEventListener(ev, set(false)));
});
ui.start.addEventListener("click", startGame);

// ---------- Game state ----------
const BLOCK = 300;          // size of one city block (road + building)
const ROAD = 90;            // road width
const state = { mode: "menu", score: 0, coins: 0, time: 0, best: Number(localStorage.getItem("np_best") || 0) };
ui.best.textContent = state.best;

let player, cops, pickups, sparks;

function startGame() {
  player = { x: 0, y: 0, angle: -Math.PI / 2, speed: 0, health: 3, hurt: 0 };
  cops = []; pickups = []; sparks = [];
  Object.assign(state, { mode: "play", score: 0, coins: 0, time: 0, spawnTimer: 0 });
  for (let i = 0; i < 2; i++) spawnCop();
  for (let i = 0; i < 6; i++) spawnPickup();
  ui.menu.classList.add("hidden");
  updateHud();
}

function spawnAround(minDist, maxDist) {
  const a = Math.random() * Math.PI * 2, d = minDist + Math.random() * (maxDist - minDist);
  return { x: player.x + Math.cos(a) * d, y: player.y + Math.sin(a) * d };
}
function spawnCop() {
  const p = spawnAround(500, 800);
  cops.push({ x: p.x, y: p.y, angle: Math.random() * 6.28, speed: 100, maxSpeed: 290 + Math.min(state.time * 3, 120) });
}
function spawnPickup() { const p = spawnAround(150, 700); pickups.push({ x: p.x, y: p.y }); }

// ---------- Update ----------
function update(dt) {
  state.time += dt;
  // Player driving: accelerate, brake, steer (steering scales with speed).
  const MAX = 360, ACCEL = 260, BRAKE = 420, DRAG = 110;
  if (keys.up) player.speed += ACCEL * dt;
  else if (keys.down) player.speed -= BRAKE * dt;
  else player.speed -= Math.sign(player.speed) * Math.min(Math.abs(player.speed), DRAG * dt);
  player.speed = Math.max(-120, Math.min(MAX, player.speed));
  const steer = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
  player.angle += steer * 2.6 * dt * Math.max(-1, Math.min(1, player.speed / 140));
  player.x += Math.cos(player.angle) * player.speed * dt;
  player.y += Math.sin(player.angle) * player.speed * dt;
  player.hurt = Math.max(0, player.hurt - dt);

  // Police: turn toward the player and chase.
  for (const c of cops) {
    const want = Math.atan2(player.y - c.y, player.x - c.x);
    let diff = Math.atan2(Math.sin(want - c.angle), Math.cos(want - c.angle));
    c.angle += Math.max(-1, Math.min(1, diff)) * 2.2 * dt;
    c.speed = Math.min(c.maxSpeed, c.speed + 140 * dt);
    c.x += Math.cos(c.angle) * c.speed * dt;
    c.y += Math.sin(c.angle) * c.speed * dt;
    // Keep cops from stacking on each other.
    for (const o of cops) if (o !== c) {
      const dx = c.x - o.x, dy = c.y - o.y, d = Math.hypot(dx, dy) || 1;
      if (d < 36) { c.x += dx / d * (36 - d) / 2; c.y += dy / d * (36 - d) / 2; }
    }
    // Crash into the player.
    if (Math.hypot(player.x - c.x, player.y - c.y) < 30 && player.hurt <= 0) {
      player.health--; player.hurt = 1.2; c.speed = 60;
      player.speed *= 0.4;
      for (let i = 0; i < 14; i++) sparks.push({ x: player.x, y: player.y, vx: (Math.random() - .5) * 300, vy: (Math.random() - .5) * 300, life: .5 });
      if (player.health <= 0) return endGame();
    }
  }

  // Coins.
  pickups = pickups.filter(p => {
    if (Math.hypot(player.x - p.x, player.y - p.y) < 28) { state.coins++; state.score += 50; spawnPickup(); return false; }
    return Math.hypot(player.x - p.x, player.y - p.y) < 1200;
  });
  // Cull far cops and add new ones over time (more cops the longer you survive).
  cops = cops.filter(c => Math.hypot(player.x - c.x, player.y - c.y) < 1600);
  state.spawnTimer += dt;
  const target = 2 + Math.floor(state.time / 12);
  if (state.spawnTimer > 3 && cops.length < Math.min(target, 12)) { spawnCop(); state.spawnTimer = 0; }

  sparks.forEach(s => { s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt; });
  sparks = sparks.filter(s => s.life > 0);

  state.score += Math.abs(player.speed) * dt * 0.05;
  updateHud();
}

function endGame() {
  state.mode = "over";
  const final = Math.floor(state.score);
  if (final > state.best) { state.best = final; localStorage.setItem("np_best", final); }
  ui.best.textContent = state.best;
  ui.menu.querySelector("h1").textContent = "Busted";
  ui.menu.querySelector("p").textContent = `You scored ${final} and collected ${state.coins} coins. Your best is ${state.best}.`;
  ui.start.textContent = "Drive again";
  ui.menu.classList.remove("hidden");
}

function updateHud() {
  ui.score.textContent = Math.floor(state.score);
  ui.coins.textContent = state.coins;
  ui.health.textContent = player ? player.health : 3;
}

// ---------- Drawing ----------
function drawCar(x, y, angle, body, roof, flash) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(angle);
  ctx.fillStyle = body; ctx.fillRect(-18, -10, 36, 20);
  ctx.fillStyle = roof; ctx.fillRect(-6, -8, 14, 16);
  ctx.fillStyle = "#fff6c8"; ctx.fillRect(16, -9, 3, 5); ctx.fillRect(16, 4, 3, 5);
  if (flash) { ctx.fillStyle = Math.floor(performance.now() / 120) % 2 ? "#ff2b2b" : "#2b7bff"; ctx.fillRect(-4, -9, 8, 18); }
  ctx.restore();
}

function drawWorld(cam) {
  const w = canvas.width, h = canvas.height;
  ctx.fillStyle = "#2b3a33"; ctx.fillRect(0, 0, w, h);       // blocks (grass/buildings)
  ctx.fillStyle = "#1b1f27";                                  // roads on a grid
  const x0 = Math.floor((cam.x - w / 2) / BLOCK) * BLOCK, y0 = Math.floor((cam.y - h / 2) / BLOCK) * BLOCK;
  for (let gx = x0; gx < cam.x + w / 2 + BLOCK; gx += BLOCK) ctx.fillRect(gx - ROAD / 2 - cam.x + w / 2, 0, ROAD, h);
  for (let gy = y0; gy < cam.y + h / 2 + BLOCK; gy += BLOCK) ctx.fillRect(0, gy - ROAD / 2 - cam.y + h / 2, w, ROAD);
  ctx.strokeStyle = "#e8b923"; ctx.lineWidth = 3; ctx.setLineDash([22, 18]);
  for (let gx = x0; gx < cam.x + w / 2 + BLOCK; gx += BLOCK) { const sx = gx - cam.x + w / 2; ctx.beginPath(); ctx.moveTo(sx, 0); ctx.lineTo(sx, h); ctx.stroke(); }
  for (let gy = y0; gy < cam.y + h / 2 + BLOCK; gy += BLOCK) { const sy = gy - cam.y + h / 2; ctx.beginPath(); ctx.moveTo(0, sy); ctx.lineTo(w, sy); ctx.stroke(); }
  ctx.setLineDash([]);
}

function render() {
  const w = canvas.width, h = canvas.height;
  if (!player) { ctx.fillStyle = "#1b1f27"; ctx.fillRect(0, 0, w, h); return; }
  const cam = { x: player.x, y: player.y };
  drawWorld(cam);
  const sx = x => x - cam.x + w / 2, sy = y => y - cam.y + h / 2;
  for (const p of pickups) { ctx.fillStyle = "#ffd54a"; ctx.beginPath(); ctx.arc(sx(p.x), sy(p.y), 9, 0, 6.28); ctx.fill(); ctx.strokeStyle = "#a07d00"; ctx.lineWidth = 2; ctx.stroke(); }
  for (const c of cops) drawCar(sx(c.x), sy(c.y), c.angle, "#f1f1f1", "#222", true);
  if (!(player.hurt > 0 && Math.floor(player.hurt * 12) % 2)) drawCar(sx(player.x), sy(player.y), player.angle, "#ff7a1a", "#3a1d06", false);
  ctx.fillStyle = "#ffcf6b"; for (const s of sparks) ctx.fillRect(sx(s.x), sy(s.y), 3, 3);
}

// ---------- Main loop ----------
let last = performance.now();
function loop(now) {
  const dt = Math.min((now - last) / 1000, 0.05); last = now;
  if (state.mode === "play") update(dt);
  render();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
